<?php
session_start();

$visitas = 1;
if (isset($_COOKIE['visitas'])) {
    $visitas = $_COOKIE['visitas'];
}

$mensaje = "";

//si entras al casino
if (isset($_COOKIE['disponible'])) {
    if(empty($_COOKIE['cantinicial'])) {
        require_once "bienvenida.php";
    } else {
        //indico la cantidad disponible
        $_SESSION['disponible'] = $_POST['cantinicial'];
        header("Resfresh:0");
    }
    exit();
}

//al ingresar una apuesta
if (isset($_POST['apostar'])) {
    if (is_numeric($_POST['cantidad']) and ($_POST['cantidad'] > 0)) {
        $mensaje = LaApuesta($_POST['cantidad'], $_POST['disponible'], $_POST['apuesta']);
    } else {
        $mensaje = "La cantidad apostada: " . $_POST['cantidad'] . "no es válida";
    }
}

//si abandona o no le queda disponible para apostar
if (isset($_POST['abandonar']) || ($_SESSION['disposible'] == 0)) {
    abandonarCasino($visitas);
    require_once "despedida.php";
    exit();
}

require_once "apuesta.php";

//Funciones

function LaApuesta(int $valorapuesta, int &$saldodisponible, string $apuesta): String
{
    $resultado = "";
    if ($valorapuesta > $saldodisponible) {
        $resultado .= "Error: no dispone de " . $valorapuesta . " euros disponibles. ";
    } else {
        $resultado = (random_int(1, 100) % 2 == 0) ? "PAR" : "IMPAR";
        $resultado .= " RESULTADO DE LA APUESTA : " . $resultado;
        if ($apuesta == $resultado) {
            $resultado .= " Has Ganado <br>";
            $saldodisponible  += $valorapuesta;
        } else {
            $resultado .= " Has perdido, vuelve a intentarlo <br>";
            $saldodisponible  -= $valorapuesta;
        }
    }
    return $resultado;
}

function abandonarCasino($visitasrealizadas)
{
    $visitasrealizadas++;
    setcookie("visitasalcasino", $visitasrealizadas, time() + 30 * 24 * 3600); // Un mes  
    session_destroy();
}
?>