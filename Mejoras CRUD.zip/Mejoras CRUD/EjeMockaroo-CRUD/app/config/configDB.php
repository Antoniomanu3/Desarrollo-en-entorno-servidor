<?php
const DB_SERVER = '127.0.0.1';
const DB_USER = 'root';
const DB_PASSWD = 'root';
const DATABASE = 'TestMockaroo';

