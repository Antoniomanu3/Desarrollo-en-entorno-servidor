<?php
session_start();

$_SESSION['pedidos'] = [];

if (isset($_SESSION['cliente'])) {
    require_once('index-inicio.php');
    exit();
}
if (isset($_POST["accion"])) {

    if ($_POST["accion"] == "Anotar") {
        if (isset($_SESSION['pedidos'][$_POST['fruta']])) {
            $_SESSION['pedidos'] [$_POST['fruta']] += [$_POST['cantidad']];
        } else {
            $_SESSION['pedidos'] [$_POST['fruta']] = [$_POST['cantidad']];
        }
    }

    if ($_POST["accion"] == "Terminar") {
        $compraRealizada = tablaPedidos();
        require_once ('recapitulacion.php');
        session_destroy();
        exit();
    }
}

$compraRealizada = tablaPedidos();
require_once('pedido.php');

function tablaPedidos():String {
    $mensaje = "";
    if (count($_SESSION['pedidos']) > 0) {
        $mensaje .= "Este es su pedido :";
        $mensaje .= "<table style='border: 1px solid black;'>";
        foreach ($_SESSION['pedidos'] as $key => $value) {
            $mensaje .= "<tr> <td> <b>" . $key . "</b> <td> </td> </tr>";
        }
        $mensaje .= "</table>";
    }
    return $mensaje;
}
?>
