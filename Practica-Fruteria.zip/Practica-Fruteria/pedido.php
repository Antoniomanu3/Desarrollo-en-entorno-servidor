<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practica-fruteria</title>
</head>
<body>
    <h1> La fruteria del siglo XXI </h1>
    <B><br> REALICE SU COMPRA <?= $_SESSION["cliente"] ?></B></br>
        <form action="" method="post"></form>
        <b> SELECCIONE LA FRUTA: <select name="fruta">
            <option value="Naranja">Naranja</option>
            <option value="Manzana">Manzana</option>
            <option value="Platano">Plátano</option>
            <option value="Limones">Limones</option>
            
            </select>
            Cantidad: <input name="cantidad" type="number" value=0>
                <input type ="submit" name="accion" value="Anotar">
                <input type ="submit" name="accion" value="Terminar">
        </form>
</body>
</html>