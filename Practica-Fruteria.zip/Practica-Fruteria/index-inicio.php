<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practica-fruteria</title>
</head>
<body>
    <h1> La fruteria del siglo XXI </h1>
    <b> BIENVENIDO A NUESTRA FRUTERIA DEL SIGLO XXI </B>
    <form action="lafruteria.php" method="GET">
        Introduzca su nombre de cliente: <input type="text" name="cliente">
    </form>
</body>
</html>